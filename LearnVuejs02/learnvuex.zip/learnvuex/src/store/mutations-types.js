export const INCREMENT = 'increment';
export const DECREMENT = 'decrement';
export const ADDCOUNTE = 'addCounte';
export const ADDSTU = 'addStu';
export const ADDSTUTYPE = 'addStuType';
export const UPDATEINFO = 'updateInfo';
